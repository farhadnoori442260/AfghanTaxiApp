package com.example.taxiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}